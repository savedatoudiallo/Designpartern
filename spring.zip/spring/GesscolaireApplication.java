package ism.gesscolaire;
import ism.gesscolaire.entities.Classe;
import ism.gesscolaire.repositories.ClasseRepositories;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class GesscolaireApplication implements CommandLineRunner {


	public static void main(String[] args) {

		SpringApplication.run(GesscolaireApplication.class, args);

	}
	@Autowired
	private ClasseRepositories classeRepositories;

	@Override
	@Transactional
	public void run(String... args) throws Exception {
/*

		Classe classe = new Classe("GLRS","L3");

		classeRepositories.save(classe);
		Classe classe1 = new Classe("MAE","L3");

		classeRepositories.save(classe1);

		Classe classe2 = new Classe("CDSD","L3");

		classeRepositories.save(classe2);

*/


	}
}
