package ism.gesscolaire.entities;


import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.Set;

@Entity
@Table(name="classe")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class Classe {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;



    @Column(nullable = false)
    private String filiere;

    @Column(nullable = false)
    private String niveau;

    @Column(nullable = false)
    private String libelle;

    public Classe(String filiere, String niveau) {
        this.filiere = filiere;
        this.niveau = niveau;
        this.libelle = filiere + " " + niveau;
    }


    //OneToMany avec Etudiants
    @OneToMany(mappedBy = "classe")
    private Set<Etudiants> etudiant;

}
